===
coloring string
===

```
import coloring_string as cs
print(cs.red('hello'))
```
